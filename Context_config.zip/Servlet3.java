package com.program.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Servlet3 extends HttpServlet{


		
		protected void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException {
	        PrintWriter pw=res.getWriter();
	        res.setContentType("text/html");

	        // I am using 2nd way to create Context object
	        ServletContext context=getServletContext();  
	        ServletConfig  config=getServletConfig();

	        String s1=context.getInitParameter("a");
	        int a=Integer.parseInt(s1);
	        String s2=context.getInitParameter("b");
	        int b=Integer.parseInt(s2);
	        String s3=context.getInitParameter("c");
	        int c=Integer.parseInt(s3);
	        
	        String s4=config.getInitParameter("d");
	        int d=Integer.parseInt(s4);

	        pw.println("Addition of three number:"+(a+b+d));
	        
	        if(a>b && a>c && a>d) {
	        		pw.println("Greater number is A:"+a);
	        }else if(b>a && b>c && b>d) {
	        		pw.println("Greater number is B:"+b);
	        }
	        else if(c>a && c>b && c>d) {
	        		pw.println("Greater number is C:"+c);
	        }
	        else {
	        	pw.println("Greater number is D:"+d);
	        }
	       pw.close();    
	    }

	}



