package com.program.servlets;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

@WebFilter("/ValidFilter")
public class ValidFilter implements Filter {

	public void destroy() {
		// TODO Auto-generated method stub
	}

	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {

		String s1=req.getParameter("user");
		String s2=req.getParameter("age");
		int age=Integer.parseInt(s2);
		
		if(s1!=null && age!=0)
		{
		res.getWriter().write("Now in the validation filter...<br>");
		chain.doFilter(req, res);
		res.getWriter().write("after validation filter...<br>");
		}
		else
		{
			res.getWriter().write("Blocked in the validation filter...<br>");
		}
		
	}

	public void init(FilterConfig fconfig) throws ServletException {
		// TODO Auto-generated method stub
		
	}
}

