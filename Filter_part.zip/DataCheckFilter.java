package com.program.servlets;

	import java.io.IOException;
	import javax.servlet.Filter;
	import javax.servlet.FilterChain;
	import javax.servlet.FilterConfig;
	import javax.servlet.ServletException;
	import javax.servlet.ServletRequest;
	import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
@WebFilter("/DataCheckFilter")
public class DataCheckFilter implements Filter {
	public void destroy() {
		// TODO Auto-generated method stub
	}

	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		
		String s1=req.getParameter("user");
		String s2=req.getParameter("age");
		int age=Integer.parseInt(s2);
		if("admin".equals(s1) && age==30)
		{
			res.getWriter().write("Now in the Datacheckfilter....<br>");
		chain.doFilter(req, res);
		res.getWriter().write("<br>after Datacheckfilter....<br>");
		}else
		{
			res.getWriter().write("Blocked in the Datacheckfilter...<br>");
		}
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}

