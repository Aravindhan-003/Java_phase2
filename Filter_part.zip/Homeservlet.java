package com.program.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Homeservlet extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	
		String s1=req.getParameter("user");
		String s2=req.getParameter("age");
		int age=Integer.parseInt(s2);
		PrintWriter out=res.getWriter();
		out.println("Welcome "+s1+" your age is "+age);
	}

}
