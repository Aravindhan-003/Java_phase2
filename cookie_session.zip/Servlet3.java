package com.program.exercise;

import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Servlet3 extends HttpServlet{
	
	public void doPost(HttpServletRequest request, HttpServletResponse response){
	     try{
	      response.setContentType("text/html");
	      PrintWriter pwriter = response.getWriter();

	      String name = request.getParameter("user");
	      String password = request.getParameter("pass");
	      String s2= request.getParameter("age");
	      int age=Integer.parseInt(s2);
	      String mail = request.getParameter("email");
	      String country = request.getParameter("country");
	      
	      pwriter.print("Hello "+name);
	      pwriter.print("Your Password is: "+password);
	      pwriter.print("Your age is: "+age);
	      pwriter.print("Your e-mailID is: "+mail);
	      pwriter.print("Your country location is: "+country);
	      
	      //creating the HttpSession below
	      HttpSession session=request.getSession(); 
	      
	      session.setAttribute("uname",name);
	      session.setAttribute("upass",password);
	      session.setAttribute("uage",age);
	      session.setAttribute("umail",mail);
	      session.setAttribute("ucountry",country);
	      
	      pwriter.print("<a href='welcome'>view details</a>");
	      pwriter.close();
	    }catch(Exception exp){
	       System.out.println(exp);
	     }
	  }
}
