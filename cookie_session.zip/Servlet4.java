package com.program.exercise;

import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Servlet4 extends HttpServlet{
	
	public void doGet(HttpServletRequest request, HttpServletResponse response){
		  try{
		      response.setContentType("text/html");
		      PrintWriter pwriter = response.getWriter();
		     
		      HttpSession session=request.getSession(false);
		      
		      String myName=(String) session.getAttribute("uname");
		      String myPass=(String)session.getAttribute("upass");
		      int myage=(int)session.getAttribute("uage");
		      String mymail=(String)session.getAttribute("umail");
		      String mycountry=(String)session.getAttribute("ucountry");
		      
		      pwriter.println("session creation time "+ session.getCreationTime());
		      pwriter.println("session last accessed time " +session.getLastAccessedTime());
		      pwriter.println("session servelt context " +session.getId() );
		      
		      pwriter.print("Name: "+myName+ "and age is: "+myage+" Pass: "+myPass);
		      pwriter.print("E-mailID is: "+mymail+" Country is: "+mycountry);
		      pwriter.close();
		  }catch(Exception exp){
		      System.out.println(exp);
		   }
		  }
}
