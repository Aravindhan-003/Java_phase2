package com.program.servlets;

public class Gethandler {

}
